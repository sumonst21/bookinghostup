=== Custom Post Type Plus ===
Contributors: MotoPress
Donate link: https://motopress.com/
Tags: custom post type
Requires at least: 4.0
Tested up to: 4.9
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin lets you add several custom post types in your WordPress.

== Description ==

This plugin lets you add several custom post types in your WordPress.

== Installation ==

1. Upload the MotoPress plugin to the /wp-content/plugins/ directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.


== Screenshots ==

== Copyright ==

Custom Post Type Plus plugin, Copyright (C) 2018, MotoPress https://motopress.com/
Custom Post Type Plus plugin is distributed under the terms of the GNU GPL.


== Changelog ==

= 1.1.0 =
* Minor bugfixes and improvements.

= 1.0.0 =
* Initial release